package com.hit.serverstatus;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class StatObj {
	String time;
	 
	Long currentUsers;
	Long maxUsers;
	Double avarageDatamodelID;
	Map<String, String>[] userID;
	
	public StatObj() {
		
	}
	
	public void setTime(){
		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
		Date now = new Date();
		time = timeFormat.format(now);
	}
	
	public String getTime(){
		
		return time;
	}
	
	public void setCurrentUsers(Long flag){
		currentUsers +=flag;
	}
	
	public Long getCurrentUsers(){
		
		return currentUsers;
	}
	public void setMaxUsers(Long max){
		maxUsers = max;
	}
	
	public Long getMaxUsers(){
		
		return maxUsers;
	}
	public void setAvarageDatamodelID(Integer avg){
		
		avarageDatamodelID = (avarageDatamodelID*userID.length+avg)/(userID.length+1);
	}
	
	public Double getAvarageDatamodelID(){
		
		return avarageDatamodelID;
	}
	@SuppressWarnings("unchecked")
	public void setUserID(Map<String, String> ids){
		List<Map<String, String>> users = new ArrayList<>();
		users.add(ids);		
	
		userID = (Map<String, String>[]) users.toArray();
	}
	
	public Map<String, String>[] getUserID(){
		
		return userID;
	}
	
	
	
	public String toString(){
		
		return time + " " + currentUsers.toString() + " " + maxUsers.toString() + " " + avarageDatamodelID.toString() + " " + userID.toString();
	}
}
