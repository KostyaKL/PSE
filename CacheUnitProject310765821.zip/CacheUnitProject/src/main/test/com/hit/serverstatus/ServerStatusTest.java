package com.hit.serverstatus;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

class ServerStatusTest {

	ServerStatus serverStatus;
	StatObj stat;

	public ServerStatusTest() {
		stat.setAvarageDatamodelID(5);
		stat.setCurrentUsers(new Long(19));
		stat.setMaxUsers(new Long(34));
		stat.setTime();
		
		Map<String, String> userID;
		userID = new HashMap<String, String>();
		userID.put("userId", UUID.randomUUID().toString());
		userID.put("Requests", UUID.randomUUID().toString());
		stat.setUserID(userID);
		serverStatus = new ServerStatus(stat);
	}
	
	@Test
	void get() {
		
		serverStatus.get();
		Assert.assertEquals("dataModelId:0,content:null", "dfgdf");

	}
}
